<?php defined('BASEPATH') or exit('No direct script access allowed');

class Qr_genrat extends CI_Controller

{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		// $this->load->model(['admin_model','dynamic_model','front_model']);
		// $this->load->model('firebase_model');
		$this->load->library(['session','ci_qr_code']);
		// $this->load->library('form_validation');
		// $this->load->helper('form');
		$this->config->load('qrcode');
		// $this->load->library('form_validation');
		// $this->load->library('user_agent');
	}

public function index()
{
	print_r('hello');die;
}
// public function generate() {
// 		// print_r($_POST['qr_text']);die;
//         // Generate and display the QR code
//         $text = 'upi://pay?pa=som.gate12345@okicici&pn=som&tr=test&tn=test&am=1&cu=INR';
		
//         // Load the QR Code Library
//         // $this->load->library('Ci_qr_code');

//         $config['cacheable'] = $this->config->item('cacheable');
//         $config['cachedir'] = $this->config->item('cachedir');
//         $config['imagedir'] = $this->config->item('imagedir');
//         $config['errorlog'] = $this->config->item('errorlog');
//         $config['ciqrcodelib'] = $this->config->item('ciqrcodelib');
//         $config['quality'] = $this->config->item('quality');
//         $config['size'] = $this->config->item('size');
//         $config['black'] = $this->config->item('black');
//         $config['white'] = $this->config->item('white');
// 		// print_r($config);die;
//         $this->ci_qr_code->initialize($config);

//         $qr_code_image = 'uploads/qr/' . uniqid() . '.png'; // You can customize the path and filename
//         $params['data'] = base_url($text);
//         $params['level'] = 'H';
//         $params['size'] = 4;
//         $params['savename'] = FCPATH . $qr_code_image;
		
// 		// print_r($params);die;
//         if ($this->ci_qr_code->generate($params)) {
//             // Display the generated QR code
//             $qr_code_image = base_url($qr_code_image);
		
	
// 			$this->response= ' <img height="50" width="50" src='.$qr_code_image.' >';

// 			// print_r('HELLO');

// 			return;

// 			exit();
//             // $this->load->view('show_qr_code', $data);
//         } else {
//             echo 'hello';
//         }
//     }
public function generate() {
    // Text to be encoded in the QR code
    // $text = 'upi://pay?pa=som.gate12345@okicici&pn=som&tr=test&tn=test&am=1&cu=INR';
    $text = 'upi://pay?pa=rahulbirlars20@oksbi&pn=rahul&tr=test&tn=test&am=1&cu=INR';

    // Configuration settings
    $config['cacheable'] = $this->config->item('cacheable');
    $config['cachedir'] = $this->config->item('cachedir');
    $config['imagedir'] = $this->config->item('imagedir');
    $config['errorlog'] = $this->config->item('errorlog');
    $config['ciqrcodelib'] = $this->config->item('ciqrcodelib');
    $config['quality'] = $this->config->item('quality');
    $config['size'] = $this->config->item('size');
    $config['black'] = $this->config->item('black');
    $config['white'] = $this->config->item('white');

    // Initialize the QR Code library
    $this->ci_qr_code->initialize($config);

    // Path to save the generated QR code image
    $qr_code_image = 'uploads/qr/' . uniqid() . '.png';

    // Parameters for the QR code generation
    $params['data'] = $text;  // Text to encode in the QR code
    $params['level'] = 'H';
    $params['size'] = 4;
    // $params['savename'] = FCPATH .'uploads/qr'. $qr_code_image;
	$params['savename'] = FCPATH . '/' . $qr_code_image;
// print_r(FCPATH);die;
// echo 'FCPATH: ' . FCPATH . '<br>';
// echo 'qr_code_image: ' . $qr_code_image . '<br>';
// echo 'params: ' . print_r($params, true) . '<br>';die;
    // Generate the QR code
    if ($this->ci_qr_code->generate($params)) {
        // Get the URL to the generated QR code image
        $qr_code_image_url = base_url($qr_code_image);

        // Display the generated QR code
        $this->response = '<img height="50" width="50" src="' . $qr_code_image_url . '">';
        echo $this->response;
    } else {
        echo 'QR code generation failed.';
    }
}

	public function view_folde_images()
	{
				
		$projectId = $_GET['project_id'];
		$events = $this->db->where('project_id', $projectId)->get('events')->result_array();


		$allEventFolders = array();

		foreach ($events as $event) {
		
			$folders = $this->db->where('event_id', $event['id'])->get('folder')->result_array();
			

			$allEventFolders = array_merge($allEventFolders, $folders);
		}
		$allImages = array();
		foreach ($allEventFolders as $allfolder){

			$images =  $this->db->where('folder_id',$allfolder['id'])->get('gallery')->result_array();
			

			$allImages = array_merge($allImages, $images);
		}
		$data['images'] = $allImages;
		$data['count'] = count($allImages);;

		// echo "<pre>";
		// print_r($allImages);die;
		// echo "</pre>";
		$this->load->view('home/phone-view3',$data);
	}
}